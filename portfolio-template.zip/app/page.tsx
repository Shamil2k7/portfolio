import Nav from "./components/Nav";
import Hero from "./components/Hero";
import WorkList from "./components/WorkList";
import About from "./components/About";

export default function Home() {
  return (
    <main className="bg-[var(--cream)] text-[var(--ink)]">
      <Nav />
      <Hero />
      <WorkList />
      <About />
    </main>
  );
}
