export default function About() {
  return (
    <section id="recognitions" className="relative px-6 md:px-10 py-24 md:py-32 border-t border-[var(--line)]">
      <div className="grid md:grid-cols-2 gap-16">
        <div>
          <p className="font-display text-3xl md:text-[2.75rem] leading-[1.15]">
            Jonas is a Senior Interactive Designer at{" "}
            <span className="text-[var(--moss)]">Studio&nbsp;Halden</span>. Specializing in
            combining motion &amp; branding to create award-winning websites. Living in
            Copenhagen, Denmark — Jonas enjoys long runs by the harbour &amp; building
            odd little tools for the web.
          </p>
          <p className="mt-8 text-xs tracking-[0.15em] uppercase text-[var(--ink-soft)]">
            ( Placeholder bio — swap in your own story )
          </p>
        </div>

        <div id="contact" className="flex flex-col gap-10">
          <div>
            <p className="text-xs tracking-[0.2em] uppercase text-[var(--moss)] mb-2">
              Let&apos;s do some awesome work
            </p>
            <a
              href="mailto:hello@example.com"
              className="font-display italic text-2xl md:text-3xl hover:opacity-70 transition-opacity"
            >
              hello@example.com
            </a>
          </div>

          <div>
            <p className="text-xs tracking-[0.2em] uppercase text-[var(--moss)] mb-3">
              Socials
            </p>
            <div className="flex gap-6 font-display italic text-lg">
              <a href="#" className="hover:opacity-60 transition-opacity">
                LinkedIn
              </a>
              <a href="#" className="hover:opacity-60 transition-opacity">
                Instagram
              </a>
              <a href="#" className="hover:opacity-60 transition-opacity">
                Awwwards
              </a>
            </div>
          </div>
        </div>
      </div>

      <footer className="mt-24 flex items-center justify-between text-xs tracking-[0.15em] uppercase text-[var(--ink-soft)]">
        <span>© {new Date().getFullYear()} Jonas Kaas</span>
        <span>Back to top ↑</span>
      </footer>
    </section>
  );
}
