"use client";

function MarqueeRow({ words, outline = false, reverse = false }: { words: string; outline?: boolean; reverse?: boolean }) {
  const item = (
    <span
      className={`font-display italic ${outline ? "text-outline" : "text-[var(--ink)]"} text-[12vw] leading-none pr-10 select-none`}
    >
      {words}
    </span>
  );
  return (
    <div className={`marquee-track ${reverse ? "reverse" : ""}`}>
      {item}
      {item}
    </div>
  );
}

export default function Hero() {
  return (
    <section id="top" className="relative w-full h-screen min-h-[720px] overflow-hidden pt-28">
      <div className="absolute inset-0 flex flex-col justify-center gap-2 opacity-90">
        <MarqueeRow words="KAAS · DESIGN · " />
        <MarqueeRow words="INTERACTIVE · " outline reverse />
      </div>

      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative w-[280px] md:w-[360px] aspect-[3/4] torn-mask grain shadow-2xl">
          <div className="absolute inset-0 bg-gradient-to-br from-[#c79c78] via-[#a97e58] to-[#4c3a26]" />
          <div className="absolute inset-0 flex items-center justify-center text-center px-6">
            <p className="font-display italic text-[var(--cream)] text-lg leading-snug">
              Your portrait
              <br />
              goes here
            </p>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-6 md:left-10 text-xs tracking-[0.2em] uppercase text-[var(--ink-soft)]">
        Interactive Designer
      </div>
      <div className="absolute bottom-10 right-6 md:right-10 text-xs tracking-[0.2em] uppercase text-[var(--ink-soft)]">
        Cph, Denmark
      </div>
    </section>
  );
}
