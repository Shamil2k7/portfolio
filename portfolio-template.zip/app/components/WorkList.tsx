"use client";

import { useState } from "react";
import { projects } from "../data/projects";

export default function WorkList() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <section id="work" className="relative px-6 md:px-10 py-24 md:py-32">
      <div className="flex items-center justify-between mb-16">
        <h2 className="font-display italic text-3xl md:text-4xl">Selected work</h2>
        <span className="text-xs tracking-[0.2em] uppercase text-[var(--ink-soft)]">
          {String(projects.length).padStart(2, "0")} projects
        </span>
      </div>

      <ul className="border-t border-[var(--line)]">
        {projects.map((p, i) => (
          <li
            key={p.slug}
            onMouseEnter={() => setActive(i)}
            onMouseLeave={() => setActive(null)}
            className="group relative border-b border-[var(--line)] py-8 md:py-10 grid grid-cols-2 md:grid-cols-4 items-center gap-4 cursor-pointer transition-colors"
          >
            <span className="col-span-2 md:col-span-1 font-display italic text-3xl md:text-5xl group-hover:pl-4 transition-[padding] duration-300">
              {p.title}
            </span>
            <span className="hidden md:block text-sm text-[var(--ink-soft)]">{p.agency}</span>
            <span className="hidden md:block text-sm text-[var(--ink-soft)]">{p.role}</span>
            <span className="text-right text-sm text-[var(--ink-soft)]">{p.year}</span>

            {/* Reveal image on hover, torn paper mask, follows a fixed position */}
            <div
              className={`hidden md:block pointer-events-none absolute right-24 top-1/2 -translate-y-1/2 w-40 aspect-[3/4] torn-mask transition-all duration-300 bg-gradient-to-br ${p.tone} ${
                active === i ? "opacity-100 scale-100" : "opacity-0 scale-90"
              }`}
            />
          </li>
        ))}
      </ul>
    </section>
  );
}
