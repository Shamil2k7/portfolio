export type Project = {
  slug: string;
  title: string;
  agency: string;
  role: string;
  client: string;
  year: string;
  tone: string; // gradient tone for placeholder image
};

export const projects: Project[] = [
  {
    slug: "northfare",
    title: "NORTHFARE",
    agency: "Studio Halden",
    role: "Lead Designer, Developer",
    client: "Northfare Transit",
    year: "2026",
    tone: "from-[#8a7a5c] to-[#3f3a2c]",
  },
  {
    slug: "kolonihave",
    title: "KOLONIHAVE",
    agency: "In-house",
    role: "Art Direction",
    client: "Kolonihave Coffee",
    year: "2025",
    tone: "from-[#a68b6b] to-[#5a4632]",
  },
  {
    slug: "vaerkstedet",
    title: "VÆRKSTEDET",
    agency: "Studio Halden",
    role: "Design, Motion",
    client: "Værkstedet Studio",
    year: "2025",
    tone: "from-[#93967a] to-[#3a3c2f]",
  },
  {
    slug: "solvang",
    title: "SOLVANG",
    agency: "Freelance",
    role: "Lead Designer",
    client: "Solvang Ceramics",
    year: "2024",
    tone: "from-[#b08d63] to-[#5c4527]",
  },
];
